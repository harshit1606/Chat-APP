
const socket = io();
const joinButton = document.getElementById('joinButton');
const roomInput = document.getElementById('roomInput');
const chat = document.getElementById('chat');
const messagesDiv = document.getElementById('messages');
const messageInput = document.getElementById('messageInput');
const sendButton = document.getElementById('sendButton');

joinButton.addEventListener('click', () => {
    const room = roomInput.value;
    if (room) {
        socket.emit('joinRoom', { room });
        chat.style.display = 'block';
        roomInput.disabled = true;
        joinButton.disabled = true;
    }
});

sendButton.addEventListener('click', () => {
    const message = messageInput.value;
    if (message) {
        socket.emit('sendMessage', message);
        messageInput.value = '';
    }
});

socket.on('message', (message) => {
    const msgElement = document.createElement('div');
    msgElement.innerText = message;
    messagesDiv.appendChild(msgElement);
});
